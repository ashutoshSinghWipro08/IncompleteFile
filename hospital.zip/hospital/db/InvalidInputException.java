package com.hospital.db;

public class InvalidInputException extends Exception {

	private static final long serialVersionUID = 1L;
	String exceptionName;
	public InvalidInputException(String data) {
		super(data);
		this.exceptionName=data;
	}
	public InvalidInputException() {}
	@Override
	public String toString() {
		return exceptionName;
		//return "Invalid Input Exeception";
	}
}
