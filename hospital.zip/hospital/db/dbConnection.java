package com.hospital.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class dbConnection {
	private static final String url = "jdbc:oracle:thin:@localhost:1521:xe";
	private static final String username = "system";
	private static final String password = "anas";

	public static Connection getConnection() throws SQLException {
		return DriverManager.getConnection(url, username, password);
	}
	// public static void main(String[] args)throws SQLException {
	// System.out.println(dbConnection.getConnection());
	// }
}
