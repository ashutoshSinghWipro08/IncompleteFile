package com.hospital.support;

import java.awt.Button;
import java.awt.Dialog;
import java.awt.Frame;
import java.awt.GridLayout;
import java.awt.Label;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.hospital.beans.PatientBean;
import com.hospital.db.dbConnection;
import com.hospital.db.InvalidInputException;

public class AdmitPatient {

	public String validate(PatientBean patientBean) {
		try {
			if (patientBean.getName().length() < 3) {
				throw new InvalidInputException("Name too Short");
			}
			else if(patientBean.getAddress().length() < 10)
			{
				throw new InvalidInputException("Address too short");
			}
			else if(patientBean.getComplaint().length() < 5)
			{
				throw new InvalidInputException("Complaint Length is too short");
			}
			else if(patientBean.getAmount() < 0)
			{
				throw new InvalidInputException("Amount not valid");
			}
			else if(patientBean.getContact().length() < 10)
			{
				throw new InvalidInputException("Contact length not valid");
			}
			else {
				return "SUCCESS";
			}
		} catch (InvalidInputException e) {
			System.out.println("in validate patient");
			return e.toString();
		}
	}
	public void showAlert(String message)
	{
		try
		{			
			Frame f= new Frame();  
			Dialog d = new Dialog(f , "Dialog", true);  
	        d.setLayout( new GridLayout(2,1));//new FlowLayout() );  
	        Button b = new Button ("OK");  
	        b.addActionListener ( new ActionListener()  
	        {  
	            public void actionPerformed( ActionEvent e )  
	            {  
	                d.setVisible(false);  
	            }  
	        });  
	        d.add( new Label (message));  
	        d.add(b);   
	        d.setSize(300,200);    
	        d.setVisible(true);  
		}catch(Exception e)
		{
			System.out.println(e);
		}
	}
	public String admitPatient(PatientBean patientBean) {
		String status = "";
		try {
			String validity = this.validate(patientBean);
			if (validity.equalsIgnoreCase("SUCCESS")) {
				String sql = "insert into hospitalPatients values(?,?,?,?,?,?,?,?,?,?,?)";
				PreparedStatement ps = dbConnection.getConnection().prepareStatement(sql);
				ps.setInt(1, this.generatePatientId());
				ps.setString(2, patientBean.getName());
				ps.setString(3, patientBean.getAddress());
				ps.setString(4, patientBean.getComplaint());
				ps.setInt(5, patientBean.getAmount());
				ps.setInt(6, patientBean.getDoctorId());
				ps.setString(7, patientBean.getType());
				ps.setInt(8, this.generateRoomNo());
				ps.setInt(9, 0);
				ps.setDate(10, new java.sql.Date(new java.util.Date().getTime()));
				ps.setString(11, patientBean.getContact());
				if (ps.executeUpdate() > 0) {
					status = "SUCCESS";
				} else {
					status = "FAIL";
				}
			} else { //if (validity.equalsIgnoreCase("FAIL")) {
				status = "FAIL";
				showAlert(validity);
			}
		} catch (Exception e) {
			System.out.println("in admit patient");
			System.out.println(e);
			status = "FAIL";
		}
		return status;
	}

	public int generatePatientId() {
		try {
			String sql = "select patientSequence.nextval from dual";
			PreparedStatement ps = dbConnection.getConnection().prepareStatement(sql);
			ResultSet rs = ps.executeQuery();
			if (rs==null) {
				return -1;
			} else {
				rs.next();
				return rs.getInt("nextval");
			}
		} catch (Exception e) {
			return -1;
		}
	}

	public int generateRoomNo() {
		try {
			String sql = "select * from hospitalRoom where availableseat>0";
			PreparedStatement ps = dbConnection.getConnection().prepareStatement(sql);
			ResultSet rs = ps.executeQuery();
			if (rs == null) {
				return -1;
			} else {
				int room = 0;
				while (rs.next()) {
					room = rs.getInt("roomno");
					break;
				}
				sql = "update hospitalRoom set availableseat=availableseat-1 where roomno=?";
				ps = dbConnection.getConnection().prepareStatement(sql);
				ps.setInt(1, room);
				if (ps.executeUpdate() > 0) {
					return room;
				} else {
					return -2;
				}
			}
		} catch (Exception e) {
			return -1;
		}
	}

	// public static void main(String[] args) {
	// AdmitPatient obj = new AdmitPatient();
	// System.out.println(obj.generateRoomNo());
	// }
}
