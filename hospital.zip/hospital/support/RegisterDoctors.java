package com.hospital.support;

import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.hospital.beans.DoctorBean;
import com.hospital.db.dbConnection;
import com.hospital.db.InvalidInputException;

public class RegisterDoctors {

	public String validate(String name) {
		try {
			if (name.length() < 3) {
				throw new InvalidInputException();
			} else {
				return "SUCCESS";
			}
		} catch (InvalidInputException e) {
			return "FAIL";
		}
	}

	public String register(DoctorBean docBean) {
		try {
			String validity = this.validate(docBean.getName());
			if (validity.equalsIgnoreCase("SUCCESS")) {
				String sql = "insert into hospitalDoctors values(?,?)";
				PreparedStatement ps = dbConnection.getConnection().prepareStatement(sql);
				ps.setInt(1, generateDoctorId());
				ps.setString(2, docBean.getName());
				if (ps.executeUpdate() > 0) {
					return "SUCCESS";
				} else {
					return "FAIL";
				}
			} else {
				return "FAIL";
			}
		} catch (Exception e) {
			return "FAIL";
		}
	}

	public int generateDoctorId() {
		try {
			String sql = "select doctorSequence.nextval from dual";
			PreparedStatement ps = dbConnection.getConnection().prepareStatement(sql);
			ResultSet rs = ps.executeQuery();
			if (rs==null) {
				return -1;
			} else {
				rs.next();
				return rs.getInt("nextval");
			}
		} catch (Exception e) {
			return -1;
		}
	}
	
	public static void main(String[] args) {
		DoctorBean docBean = new DoctorBean();
		docBean.setName("ashutosh");
		RegisterDoctors register = new RegisterDoctors();
		System.out.println(register.register(docBean));
	}
	
}
