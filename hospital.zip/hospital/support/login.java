package com.hospital.support;

import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.hospital.beans.UserBean;
import com.hospital.db.dbConnection;
import com.hospital.db.InvalidInputException;

public class login {

	public String loginUser(UserBean userBean) {
		try {
			PreparedStatement ps = dbConnection.getConnection()
					.prepareStatement("select * from hospitalLogin where email=? and password = ?");
			ps.setString(1, userBean.getUsername());
			ps.setString(2, userBean.getPassword());
			ResultSet rs = ps.executeQuery();
			if (!rs.next()) {
				throw new InvalidInputException();
			}
			while (rs.next()) {
				if (rs.getString("email").equals(userBean.getUsername())
						&& rs.getString("password").equals(userBean.getPassword())) {
					return userBean.getUsername();
				}
			}
		} catch (Exception e) {
			//e.printStackTrace();
			return e.toString();
		}
		return userBean.getUsername();
	}
	
	public static void main(String[] args) {
		UserBean userBean = new UserBean();
//		userBean.setName("Anas");
//		userBean.setUsername();
//		userBean.setPassword("anasanshu6837698");
//		login obj = new login();
//		System.out.println(obj.loginUser(userBean));
	}
}
