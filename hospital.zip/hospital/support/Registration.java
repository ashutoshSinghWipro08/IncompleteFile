package com.hospital.support;

import java.awt.Button;
import java.awt.Dialog;
import java.awt.Frame;
import java.awt.GridLayout;
import java.awt.Label;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.hospital.beans.UserBean;
import com.hospital.db.dbConnection;
import com.hospital.db.InvalidInputException;

public class Registration {
	
	public Registration() {
	}

	public boolean emailValidate(String email) {
		String email_pattern = "^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$";
		Pattern pattern = Pattern.compile(email_pattern);
		Matcher match = pattern.matcher(email);
		return match.matches();
	}

	public String validate(UserBean userBean) {
		try {
			if (userBean.getName().length() < 3) {
				throw new InvalidInputException("Name too Short");
			}
			else if(userBean.getUsername().length() < 6)
			{
				throw new InvalidInputException("Username too short");
			}
			else if((!emailValidate(userBean.getUsername())))
			{
				throw new InvalidInputException("Email not valid");
			}
			else if(userBean.getPassword().length() <= 8)
			{
				throw new InvalidInputException("Password too Short");
			}			
			else 
			{
				return "SUCCESS";
			}
		} catch (InvalidInputException e) {
			System.out.println("in validate registration");
			return e.toString();
		}
	}
	public void showAlert(String message)
	{
		try
		{			
			Frame f= new Frame();  
			Dialog d = new Dialog(f , "Dialog", true);  
	        d.setLayout( new GridLayout(2,1));//new FlowLayout() );  
	        Button b = new Button ("OK");  
	        b.addActionListener ( new ActionListener()  
	        {  
	            public void actionPerformed( ActionEvent e )  
	            {  
	                d.setVisible(false);  
	            }  
	        });  
	        d.add( new Label (message));  
	        d.add(b);   
	        d.setSize(300,200);    
	        d.setVisible(true);  
		}catch(Exception e)
		{
			System.out.println(e);
		}
	}
	public String registerUser(UserBean userBean) {
		String status = "";
		try {
			String validity = validate(userBean);
			if (validity.equalsIgnoreCase("SUCCESS")) {
				String sql = "insert into hospitalLogin values(?,?,?,?)";
				PreparedStatement ps = dbConnection.getConnection().prepareStatement(sql);
				ps.setInt(1, generateLoginId());
				ps.setString(2, userBean.getName());
				ps.setString(3, userBean.getUsername());
				ps.setString(4, userBean.getPassword());
				int update = ps.executeUpdate();
				if (update > 0) {
					status = "SUCCESS";
				} else {
					status = "FAIL";
				}
			} else { //if (validity.equalsIgnoreCase("FAIL")) {
				status = "FAIL";
				showAlert(validity);
			}
		} catch (Exception e) {
			System.out.println("in register user");
			status = "FAIL";
		}
		return status;
	}

	public int generateLoginId() {
		try {
			String sql = "select loginSequence.nextval from dual";
			PreparedStatement ps = dbConnection.getConnection().prepareStatement(sql);
			ResultSet rs = ps.executeQuery();
			if (rs==null) {
				return -1;
			} else {
				rs.next();
				return rs.getInt("nextval");
			}
		} catch (Exception e) {
//			e.printStackTrace();
			System.out.println("in login id");
			return -1;
		}
	}

//	 public static void main(String[] args) {
//		 Registration obj = new Registration();
//		 UserBean userBean = new UserBean();
//		 userBean.setName("anas122");
//		 userBean.setPassword("anasanshu6837698");
//		 userBean.setUsername("anasanshu68@gmail.com");
//		 System.out.println(obj.registerUser(userBean));
//		 System.out.println(obj.generateLoginId());
//	 }

}