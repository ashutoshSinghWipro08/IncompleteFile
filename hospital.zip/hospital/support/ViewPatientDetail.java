package com.hospital.support;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import com.hospital.beans.PatientBean;
import com.hospital.db.dbConnection;

public class ViewPatientDetail {

	public ArrayList<PatientBean> getViewDetail() {
		ArrayList<PatientBean> list = new ArrayList<PatientBean>();
		try {
			String sql = "select * from hospitalPatients";
			PreparedStatement ps = dbConnection.getConnection().prepareStatement(sql);
			ResultSet rs = ps.executeQuery();
			int count=0;
			while (rs.next()) {
				PatientBean obj = new PatientBean();
				obj.setSerialNumber(++count);
				obj.setId(rs.getInt("ID"));
				obj.setName(rs.getString("NAME"));
				obj.setAddress(rs.getString("ADDRESS"));
				obj.setComplaint(rs.getString("COMPLAINT"));
				obj.setAmount(rs.getInt("AMOUNT"));
				obj.setContact(rs.getString("CONTACT"));
				obj.setDoctorId(rs.getInt("DOCTOR_ID"));
				obj.setType(rs.getString("TYPE"));
				obj.setRoomNo(rs.getInt("ROOM_NO"));
				obj.setStatus(rs.getInt("STATUS"));
				obj.setAdmitDate(rs.getDate("ADM_DATE"));

				list.add(obj);

			}
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println(e);
			System.out.println("exception in view detail");
			return null;
		}
		return list;
	}
	public ArrayList<PatientBean> getDischargeDetail() {
		ArrayList<PatientBean> list = new ArrayList<PatientBean>();
		try {
			String sql = "select * from hospitalPatients";
			PreparedStatement ps = dbConnection.getConnection().prepareStatement(sql);
			ResultSet rs = ps.executeQuery();
			int count=0;
			while (rs.next()) {
				
				PatientBean obj = new PatientBean();
				obj.setSerialNumber(++count);
				obj.setId(rs.getInt("ID"));
				obj.setName(rs.getString("NAME"));
				obj.setAddress(rs.getString("ADDRESS"));
				obj.setComplaint(rs.getString("COMPLAINT"));
				obj.setAmount(rs.getInt("AMOUNT"));
				obj.setContact(rs.getString("CONTACT"));
				obj.setDoctorId(rs.getInt("DOCTOR_ID"));
				obj.setType(rs.getString("TYPE"));
				obj.setRoomNo(rs.getInt("ROOM_NO"));
				obj.setStatus(rs.getInt("STATUS"));
				obj.setAdmitDate(rs.getDate("ADM_DATE"));
				if(obj.getStatus()==0)
					list.add(obj);

			}
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println(e);
			System.out.println("exception in view detail");
			return null;
		}
		return list;
	}
	public ArrayList<PatientBean> getViewDetailTemp()
	{
		ArrayList<PatientBean> list=new ArrayList<PatientBean>();
		try
		{
			int i=0;		
			while(i<10)
			{
				PatientBean obj=new PatientBean();
				obj.setSerialNumber(i+1);
				obj.setId(i+10);
				obj.setName("Name "+i);
				obj.setAddress("Address "+i);
				obj.setComplaint("Complaint "+i);
				obj.setAmount(100+i);
				obj.setContact(String.valueOf(102354566+i));
				obj.setDoctorId(123+i);
				obj.setType("In patient");
				obj.setRoomNo(103+i);
				obj.setStatus(i%2);
				obj.setAdmitDate(new java.sql.Date(new java.util.Date().getTime()));
				//obj.setFinalAmount(1023+i);
				
				list.add(obj);
				i++;
				
			}
		}catch(Exception e)
		{
			System.out.println(e);
			System.out.println("exception in view detail");
		}
		return list;
	}

	public int dischargePatient(int id) {
		try {
			System.out.println(" id is "+id);
			int updateStatus = 0;
			int updateRoom = 0;
			int room_no = 0;
			String sql = "select room_no from hospitalPatients where id=?";
			PreparedStatement ps = dbConnection.getConnection().prepareStatement(sql);
			ps.setInt(1, id);
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				room_no = rs.getInt("room_no");
			}
			if (room_no > 0) {
				sql = "update hospitalPatients set status=?,room_no=? where id=?";
				ps = dbConnection.getConnection().prepareStatement(sql);
				ps.setInt(1, 1); // 1 signifies that the patient has been discharged. 0 here indicates that
									// patient is still occupying bed
				ps.setInt(2, 0);// 0 indicates no room has been allotted and the previously occupied room has
								// been released
				ps.setInt(3, id);
				updateStatus = ps.executeUpdate();
				sql = "update hospitalRoom set availableseat = availableseat+1 where roomno = ?";
				ps = dbConnection.getConnection().prepareStatement(sql);
				ps.setInt(1, room_no);
				updateRoom = ps.executeUpdate();
				System.out.println("room ="+updateRoom+", status = "+updateStatus);
			}
			if (updateStatus > 0 && updateRoom > 0) {
				dbConnection.getConnection().prepareStatement("commit").executeUpdate();
				return 1;
			} else {
				dbConnection.getConnection().prepareStatement("rollback").executeUpdate();
				return -1;
			}
		} catch (Exception e) {
			System.out.println(e);
			System.out.println("exception in view detail");
			return -1;
		}
	}

}
