package com.hospital.beans;

public class PatientBean {
	int serialNumber;
	int id;
	String name;
	String address;
	String complaint;
	int amount;
	String contact;
	int doctorId;
	String type;
	int roomNo;
	int status;
	java.util.Date admitDate;
	String doctorName;
	
	public int getSerialNumber()
	{
		return serialNumber;
	}
	public void setSerialNumber(int serialNumber)
	{
		this.serialNumber=serialNumber;
	}
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}
	public String getDoctorName()
	{
		return doctorName;
	}
	public void setDoctorName(String doctorName)
	{
		this.doctorName=doctorName;
	}
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getComplaint() {
		return complaint;
	}

	public void setComplaint(String complaint) {
		this.complaint = complaint;
	}

	public int getAmount() {
		return amount;
	}

	public void setAmount(int amount) {
		this.amount = amount;
	}

	public String getContact() {
		return contact;
	}

	public void setContact(String contact) {
		this.contact = contact;
	}

	public int getDoctorId() {
		return doctorId;
	}

	public void setDoctorId(int doctor_id) {
		this.doctorId = doctor_id;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public int getRoomNo() {
		return roomNo;
	}

	public void setRoomNo(int room_no) {
		this.roomNo = room_no;
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	public java.util.Date getAdmitDate() {
		return admitDate;
	}

	public void setAdmitDate(java.util.Date adm_date) {
		this.admitDate = adm_date;
	}

}
