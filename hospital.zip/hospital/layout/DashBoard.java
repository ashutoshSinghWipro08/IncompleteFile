package com.hospital.layout;

import java.awt.Button;
import java.awt.CardLayout;
import java.awt.Frame;
import java.awt.GridLayout;
import java.awt.Label;
import java.awt.Panel;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.JScrollPane;
import javax.swing.JTable;

import com.hospital.beans.PatientBean;
import com.hospital.support.AdmitPatient;
import com.hospital.support.ViewPatientDetail;

class CustomPanel extends Panel {
    public CustomPanel(Panel pan) {
        refresh(pan);
    }

    public void refresh(Panel pan) {
        removeAll();
        setLayout(new GridLayout(2,1));
        add(pan);
        revalidate();
        repaint();
    }
}

public class DashBoard extends Frame{
	LoginPanel login;
	Panel menuButtonRow,admitPatient,viewDetail,mainLayout,container,dischargePatient;
	//CustomPanel dischargePatient;
	DischargeTableModel dischargeModel;
	ViewTableModel viewModel;
	JTable viewTable,dischargeTable;
	
	CardLayout card;
	DashBoard()
	{
		createDashBoardGui();
	}
	public void setLoginRef(LoginPanel obj)
	{
		login=obj;
	}
	public Panel getBasePanel()
	{
		return mainLayout;
	}
	int flag=0;
	public void createDashBoardGui()
	{
		//flag++;
		if(flag==1)
		{

			
			flag=0;
			//removeAll();
			
			dischargePatient.revalidate();

//			
			dischargePatient.repaint();
//		
		}
		else
			flag=1;
		
		
		createPanels();
		createMenuRow();
		createAdmitPanel();
		createDischargePanel();
		viewDetailPanel();
				
		
		container.add(admitPatient,"Admit Patient");
		
		//container.add(admitPatient);
		container.add(dischargePatient,"Discharge Patient");
		container.add(viewDetail,"View Patient");
		
		
		mainLayout.add(container,"Center");
		mainLayout.add(menuButtonRow,"South");
		
	}
	public void createAdmitPanel()
	{
		Panel pane=new Panel(new GridLayout(8,2));
		TextField name=new TextField();
		TextField address=new TextField();
		TextField complaint=new TextField();
		TextField amount=new TextField();
		TextField contact=new TextField();
		TextField doctorId=new TextField();
		TextField type=new TextField();
		
		pane.add(new Label("Name :"));
		pane.add(name);
		pane.add(new Label("Address :"));
		pane.add(address);
		pane.add(new Label("Complaint :"));
		pane.add(complaint);
		pane.add(new Label("Amount :"));
		pane.add(amount);
		pane.add(new Label("Contact :"));
		pane.add(contact);
		pane.add(new Label("Doctor Id :"));
		pane.add(doctorId);
		pane.add(new Label("Type :"));
		pane.add(type);
		
		Button submitBtn=new Button("SUBMIT");
		submitBtn.addActionListener(new ActionListener(){  
			@Override
			public void actionPerformed(ActionEvent e){  
				System.out.println("in submit button");
				
				PatientBean patient=new PatientBean();
				patient.setName(name.getText());
				patient.setAddress(address.getText());
				patient.setComplaint(complaint.getText());
				patient.setAmount(Integer.parseInt(amount.getText()));
				patient.setContact(contact.getText());
				patient.setDoctorId(Integer.parseInt(doctorId.getText()));
				patient.setType(type.getText());
				boolean ch=admitDataStore(patient);
				if(ch==true)
				{
					System.out.println("Data Stored ");
					name.setText("");
					address.setText("");
					complaint.setText("");
					amount.setText("");
					contact.setText("");
					doctorId.setText("");
					type.setText("");
					
				}
				else
				{
					System.out.println("Data Not Stored");
				}
			}			  
		});
		
		pane.add(submitBtn);
		
		admitPatient.add(pane);
	}
	public boolean admitDataStore(PatientBean obj)
	{
		AdmitPatient admit=new AdmitPatient();
		String res=admit.admitPatient(obj);
		if(res.equalsIgnoreCase("SUCCESS"))
			return true;
		else
			return false;
	}
	int counter=0;
	public void createDischargePanel()
	{		
		ViewPatientDetail view=new ViewPatientDetail();
		ArrayList<PatientBean> list=view.getDischargeDetail();
		
		Panel pane=new Panel();//new GridLayout(2,1));
		
		dischargeModel=new DischargeTableModel(list);
		dischargeTable=new JTable(dischargeModel);
		dischargeTable.setAutoResizeMode(dischargeTable.AUTO_RESIZE_ALL_COLUMNS);
		JScrollPane jp=new JScrollPane();
		//jp.add(table);
		pane.add(new JScrollPane(dischargeTable));
		
		Button disBtn=new Button("DISCHARGE");
		
		disBtn.addActionListener(new ActionListener(){  
			@Override
			public void actionPerformed(ActionEvent e){  
				System.out.println("in remove button");
				if(dischargeTable.getSelectedRow()!=-1)
				{
					int ch=view.dischargePatient(dischargeModel.getDischargeList().get(dischargeTable.getSelectedRow()).getId());
					//int ch=dischargeTable.getSelectedRow();
					System.out.println(ch);
					if(ch!=-1)
					{
						dischargeModel.getDischargeList().remove(dischargeTable.getSelectedRow());
						dischargeTable.repaint();
					}
					else
						System.out.println("Discharge not Possible contact admin");
					dischargeTable.clearSelection();
				}
			}			  
		});		
		
		//jp.add(disBtn);
		
		dischargePatient.add(new JScrollPane(dischargeTable));
		dischargePatient.add(disBtn);
	}
	public Panel recreate()
	{
		ViewPatientDetail view=new ViewPatientDetail();
		ArrayList<PatientBean> list=view.getViewDetail();
		
		Panel pane=new Panel();//new GridLayout(11,10));
		
		DischargeTableModel model=new DischargeTableModel(list);
		JTable table=new JTable(model);
		pane.add(new JScrollPane(table));
					
		//dischargePatient.add(pane);
		return pane;
	}
	public void viewDetailPanel()
	{
		ViewPatientDetail view=new ViewPatientDetail();
		ArrayList<PatientBean> list=view.getViewDetail();
		
		Panel pane=new Panel();//new GridLayout(11,10));
		
		viewModel=new ViewTableModel(list);
		
		
		
		viewTable=new JTable(viewModel);
		viewTable.setAutoResizeMode(viewTable.AUTO_RESIZE_ALL_COLUMNS);
		pane.add(new JScrollPane(viewTable));
		
			
		viewDetail.add(new JScrollPane(viewTable));
	}
	public void createPanels()
	{
		menuButtonRow=new Panel(new GridLayout(1,4,20,20));
		GridLayout gd=new GridLayout(2,1);
		admitPatient=new Panel(gd);
		
		dischargePatient=new Panel(new GridLayout(2,1));//CustomPanel(new Panel(/*new GridLayout(2,1)*/));
		//dischargePatient=new Panel(new GridLayout(2,2));
		viewDetail=new Panel(new GridLayout(2,1));
		card=new CardLayout();
		container=new Panel(card);
		mainLayout=new Panel(new GridLayout(2,1));
		
	}
	public void createMenuRow()
	{
		Button admitPatientBtn=new Button("Admit Patient");
		Button dischargePatientBtn=new Button("Discharge Patient");
		Button viewPatientBtn=new Button("View Patient");
		Button logOutBtn=new Button("LogOut");
		
		admitPatientBtn.addActionListener(new ActionListener(){  
			@Override
			public void actionPerformed(ActionEvent e){  
				System.out.println("in submit button");
				String str = e.getActionCommand();
				
				if(str.equals("Admit Patient"))
					card.first(container);
			}			  
		});
		
		dischargePatientBtn.addActionListener(new ActionListener(){  
			@Override
			public void actionPerformed(ActionEvent e){  
				System.out.println("in submit button");
				String str = e.getActionCommand();
				//createDischargePanel();
				dischargeModel.refresh();
				dischargeTable.repaint();
				dischargeTable.clearSelection();
				if(str.equals("Discharge Patient"))
					card.show(container,"Discharge Patient");
				//card.
			}			  
		});
		viewPatientBtn.addActionListener(new ActionListener(){  
			@Override
			public void actionPerformed(ActionEvent e){  
				System.out.println("in submit button");
				String str = e.getActionCommand();
				viewModel.refresh();
				System.out.println("size after refers"+viewModel.getViewList().size());
				viewTable.repaint();
				if(str.equals("View Patient"))
					card.last(container);
			}			  
		});
		logOutBtn.addActionListener(new ActionListener(){  
			@Override
			public void actionPerformed(ActionEvent e){  
				System.out.println("in submit button");
				String str = e.getActionCommand();
				
				if(str.equals("LogOut"))
					login.cl.first(login.basePanel);
			}			  
		});
		menuButtonRow.add(admitPatientBtn);
		menuButtonRow.add(dischargePatientBtn);
		menuButtonRow.add(viewPatientBtn);
		menuButtonRow.add(logOutBtn);
	}
	
}
