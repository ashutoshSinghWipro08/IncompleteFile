package com.hospital.layout;

import java.awt.Button;
import java.awt.CardLayout;
import java.awt.Frame;
import java.awt.GridLayout;
import java.awt.Label;
import java.awt.Panel;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class BaseFrame extends Frame{

	CardLayout cl;  
	Panel basePanel,layoutPanel,nextPanel,firstPanel;	
	Button submitBtn,registerBtn;
	TextField userName,password;
	
	BaseFrame()
	{
		createBasePage();
	}
	public void createBasePage()
	{
		try
		{
			cl=new CardLayout();
			basePanel=new Panel();
			layoutPanel=new Panel(new GridLayout(3,1));
			
			
			nextPanel=new Panel(new GridLayout(1,1));
			firstPanel=new Panel(new GridLayout(4,4));
			
			userName=new TextField();
			password=new TextField();
			
			submitBtn=new Button("SUBMIT");
			registerBtn=new Button("REGISTER");
			
			
			this.addWindowListener(new WindowAdapter() {
		         public void windowClosing(WindowEvent windowEvent){
		            System.exit(0);
		         }        
		      }); 
			
			submitBtn.addActionListener(new ActionListener(){  
				@Override
				public void actionPerformed(ActionEvent e){  
					System.out.println("in submit button");
					String str = e.getActionCommand();
					
					if(str.equals("SUBMIT"))
						cl.first(basePanel);
				}			  
				});
			registerBtn.addActionListener(new ActionListener(){  
				@Override
				public void actionPerformed(ActionEvent e){  
					System.out.println("in register button");
					String str = e.getActionCommand();
					
					if(str.equals("REGISTER"))
						cl.next(basePanel);
				}			  
				});
			
			//basePanel.add(submitBtn);
			//basePanel.add(registerBtn);
			firstPanel.add(userName);
			firstPanel.add(password);
			firstPanel.add(submitBtn);
			firstPanel.add(registerBtn);
			
//			firstPanel.add(userName);
//			firstPanel.add(password);
//			firstPanel.add(submitBtn);
			
			
			basePanel.setLayout(cl);
			basePanel.add(firstPanel);
			
			nextPanel.add(new Label("IN SECOND PAGE"));
			basePanel.add(nextPanel);
			
			
			                  // add panels to frame
		    add(layoutPanel, "South");
		    add(basePanel, "Center");  
		    
		    setSize(400, 400);  
		    setVisible(true) ;
		}catch(Exception e)
		{
			System.out.println(e);
			System.out.println(e.getMessage());
		}
		
	    
		
	}
	public static void main(String args[])
	{
		new BaseFrame();
	}
}
