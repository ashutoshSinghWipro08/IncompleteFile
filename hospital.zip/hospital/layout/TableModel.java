package com.hospital.layout;

import java.util.ArrayList;
import javax.swing.table.AbstractTableModel;

import com.hospital.beans.PatientBean;
import com.hospital.support.ViewPatientDetail;

class DischargeTableModel extends AbstractTableModel { 
	   private String[] columnNames = {"SL/No.","Name","Address","Complaint","Amount","Contact","Dr. Name","Admit Date"}; 
	   private ArrayList<PatientBean> dischargeList; 
	   	   
	   public DischargeTableModel(ArrayList<PatientBean> patientList) { 
	      this.dischargeList=patientList; 
	      /*for(int i=0;i<patientList.size();i++)
	      {
	    	  PatientBean obj=new PatientBean();
	    	  obj.setId(patientList.get(i).getId());
	    	  obj.setName(patientList.get(i).getName());
	    	  obj.setAddress(patientList.get(i).getAddress());
	    	  obj.setComplaint(patientList.get(i).getComplaint());
	    	  obj.setAmount(patientList.get(i).getAmount());
	    	  obj.setContact(patientList.get(i).getContact());
	    	  obj.setDoctorId(patientList.get(i).getDoctorId());
	    	  obj.setType(patientList.get(i).getType());
	    	  obj.setRoomNo(patientList.get(i).getRoomNo());
	    	  obj.setStatus(patientList.get(i).getStatus());
	    	  obj.setAdmitDate(patientList.get(i).getAdmitDate());

	    	  viewList.add(obj);
	      }*/
	   }
	   
	   public void addDischarge(PatientBean obj)
	   {
		   dischargeList.add(obj);
	   }
	   public void removeDischarge(int index)
	   {
		   dischargeList.remove(index);
	   }
	   public ArrayList<PatientBean> getDischargeList()
	   {
		   return dischargeList;
	   }
	   public void refresh()
	   {
		   ViewPatientDetail view=new ViewPatientDetail();
		   dischargeList=view.getDischargeDetail();
	   }
	   /*public void addView(PatientBean obj)
	   {
		   viewList.add(obj);
	   }
	   public void removeView(int index)
	   {
		   	viewList.remove(index);
	   }*/
	   public int getColumnCount() { 
	      return columnNames.length; 
	   } 
	   public int getRowCount() { 
	      int size; 
	      if (dischargeList== null) { 
	         size = 0; 
	      } 
	      else { 
	         size =dischargeList.size(); 
	      } 
	      return size; 
	   } 
	   public Object getValueAt(int row, int col) { 
	      Object temp = null; 
	      if(col==0)
	      {
	    	  temp =dischargeList.get(row).getSerialNumber();
	      }
	      else if (col == 1) { 
	         temp = dischargeList.get(row).getName(); 
	      } 
	      else if (col == 2) { 
	         temp =dischargeList.get(row).getAddress(); 
	      } 
	      else if (col == 3) { 
	         temp =dischargeList.get(row).getComplaint(); 
	      }
	      else if (col ==4) { 
		     temp =dischargeList.get(row).getAmount(); 
		  }
	      else if (col ==5) { 
			 temp =dischargeList.get(row).getContact(); 
	      }
	      else if (col ==6) { 
			temp =dischargeList.get(row).getDoctorName(); 
	      }
	      else if (col ==7) { 
			temp=dischargeList.get(row).getAdmitDate(); 
	      }
	      return temp; 
	   } 
	   public String getColumnName(int col) { 
	      return columnNames[col]; 
	   } 
	   public Class getColumnClass(int col) { 
		   if(col==0)
		   {
			 return Integer.class;
		   }
		   else if (col == 1) { 
		      return String.class; 
		   } 
		   else if (col == 2) { 
		     return String.class; 
		   } 
		   else if (col == 3) { 
		      return String.class; 
		   }
		   else if (col ==4) { 
			return Double.class; 
		   }
		   else if (col ==5) { 
			return String.class; 
		   }
		   else if (col ==6) { 
			return String.class; 
		   }
		   else{// if (col ==7) { 
			return java.util.Date.class; 
		   }
		   
	   }
	}

class ViewTableModel extends AbstractTableModel { 
	   private String[] columnNames = {"SL/No.","Name","Address","Complaint","Amount","Contact","Dr. Name","Admit Date"}; 
	   private ArrayList<PatientBean> viewList;
	   
	   public ViewTableModel(ArrayList<PatientBean> patientList) { 
	      this.viewList=patientList; 
	      System.out.println("size before any refresh"+viewList.size());
	   }
	   public ArrayList<PatientBean> getViewList()
	   {
		   return viewList;
	   }
	   public void addView(PatientBean obj)
	   {
		   viewList.add(obj);
	   }
	   public void removeView(int index)
	   {
		   	viewList.remove(index);
	   }
	   public void refresh()
	   {
		   ViewPatientDetail view=new ViewPatientDetail();
		   viewList=view.getViewDetail();
	   }
	   public int getColumnCount() { 
	      return columnNames.length; 
	   } 
	   public int getRowCount() { 
	      int size; 
	      if (viewList== null) { 
	         size = 0; 
	      } 
	      else { 
	         size =viewList.size(); 
	      } 
	      return size; 
	   } 
	   public Object getValueAt(int row, int col) { 
	      Object temp = null; 
	      if(col==0)
	      {
	    	  temp =viewList.get(row).getSerialNumber();
	      }
	      else if (col == 1) { 
	         temp = viewList.get(row).getName(); 
	      } 
	      else if (col == 2) { 
	         temp =viewList.get(row).getAddress(); 
	      } 
	      else if (col == 3) { 
	         temp =viewList.get(row).getComplaint(); 
	      }
	      else if (col ==4) { 
		     temp =viewList.get(row).getAmount(); 
		  }
	      else if (col ==5) { 
			 temp =viewList.get(row).getContact(); 
	      }
	      else if (col ==6) { 
			temp =viewList.get(row).getDoctorName(); 
	      }
	      else if (col ==7) { 
			temp=viewList.get(row).getAdmitDate(); 
	      }
	      return temp; 
	   } 
	   public String getColumnName(int col) { 
	      return columnNames[col]; 
	   } 
	   public Class getColumnClass(int col) { 
		   if(col==0)
		   {
			 return Integer.class;
		   }
		   else if (col == 1) { 
		      return String.class; 
		   } 
		   else if (col == 2) { 
		     return String.class; 
		   } 
		   else if (col == 3) { 
		      return String.class; 
		   }
		   else if (col ==4) { 
			return Double.class; 
		   }
		   else if (col ==5) { 
			return String.class; 
		   }
		   else if (col ==6) { 
			return String.class; 
		   }
		   else{// if (col ==7) { 
			return java.util.Date.class; 
		   }
		   
	   }
	}