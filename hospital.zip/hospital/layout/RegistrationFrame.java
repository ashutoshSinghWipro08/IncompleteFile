package com.hospital.layout;

import java.awt.Button;
import java.awt.Dialog;
import java.awt.Frame;
import java.awt.GridLayout;
import java.awt.Label;
import java.awt.Panel;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import com.hospital.beans.UserBean;
import com.hospital.support.Registration;

public class RegistrationFrame extends Frame{
	Panel basePanel;
	LoginPanel login;
	
	RegistrationFrame()
	{
		createForm();
	}
	public Panel getBasePanel()
	{
		return basePanel;
	}
	public void setLoginRef(LoginPanel obj)
	{
		login=obj;
	}
	public void createForm()
	{
		try
		{
			
			basePanel=new Panel(new GridLayout(6,2));
			TextField userName=new TextField();
			TextField email=new TextField();
			TextField password=new TextField();
			TextField repeatPassword=new TextField();
			Button submitBtn=new Button("SUBMIT");
			Button backBtn=new Button("BACK");
			
			submitBtn.addActionListener(new ActionListener(){  
				
				@Override
				public void actionPerformed(ActionEvent e){  
					System.out.println("in submit button");
					
					UserBean user=new UserBean();
					user.setName(userName.getText());
					user.setUsername(email.getText());
					user.setPassword(password.getText());
					
					boolean ch=validateStore(user);
					System.out.println(ch);
					if(ch==true)
						login.cl.first(login.basePanel);
				}			  
			});
			backBtn.addActionListener(new ActionListener(){  
				
				@Override
				public void actionPerformed(ActionEvent e){  
					System.out.println("in back button");
					String str = e.getActionCommand();
					if(str.equals("BACK"))
						login.cl.first(login.basePanel);
				}			  
			});
			
			basePanel.add(new Label(" Name :"));
			basePanel.add(userName);
			basePanel.add(new Label("Email :"));
			basePanel.add(email);
			basePanel.add(new Label("Password :"));
			basePanel.add(password);
			basePanel.add(new Label("Retype Password :"));
			basePanel.add(repeatPassword);
			
			basePanel.add(submitBtn);
			basePanel.add(backBtn);
			
			
		}catch(Exception e)
		{
			System.out.println(e);
			System.out.println(e.getMessage());
		}
	}
	
	public boolean validateStore(UserBean user)
	{
		try
		{		
			Registration reg=new Registration();
			String res=reg.registerUser(user);			
			if(res.equalsIgnoreCase("SUCCESS"))
				return true;
			else if(res.equalsIgnoreCase("FAIL"))
				return false;				
		}catch(Exception e)
		{
			System.out.println(e);
			System.out.println(e.getMessage());
		}
		return false;
	}
}
