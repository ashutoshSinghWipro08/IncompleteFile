package com.hospital.layout;

import java.awt.Button;
import java.awt.CardLayout;
import java.awt.Dialog;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.GridLayout;
import java.awt.Label;
import java.awt.Panel;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.lang.ref.Reference;
import java.util.Optional;

import javax.swing.JOptionPane;

import com.hospital.beans.UserBean;
import com.hospital.support.login;

public class LoginPanel extends Frame{

	CardLayout cl;  
	Panel basePanel,loginPanel;	
	Button submitBtn,registerBtn;
	TextField userName,password;
	RegistrationFrame rf;
	DashBoard dashBoard;
	public LoginPanel()
	{
		rf=new RegistrationFrame();
		dashBoard=new DashBoard();
		createBasePage();
	}
	
	public void createBasePage()
	{
		try
		{
			cl=new CardLayout();
			basePanel=new Panel();
			
			//loginPanel=new Panel(new FlowLayout(FlowLayout.CENTER,1,2));
			loginPanel=new Panel(new GridLayout(4,2,50,50));
			//loginPanel=new Panel();
		
			
			userName=new TextField();
			password=new TextField();
			
			submitBtn=new Button("SUBMIT");
			
			registerBtn=new Button("REGISTER");
			
			
			this.addWindowListener(new WindowAdapter() {
		         public void windowClosing(WindowEvent windowEvent){
		            System.exit(0);
		         }        
		      }); 
			
			submitBtn.addActionListener(new ActionListener(){  
				@Override
				public void actionPerformed(ActionEvent e){  
					System.out.println("in submit button");
					String str = e.getActionCommand();
					String uName=userName.getText().toString();
					String pass=password.getText().toString();
					boolean ch=validateData(uName, pass);
					System.out.println(ch);
					if(ch==true)
					{
						userName.setText("");
						password.setText("");
						cl.next(basePanel);
					}
					else
					{
						showAlert("USER NAME OR PASSWORD WRONG");
						System.out.println("Wrong Username or Password");
					}
				}			  
				});
			registerBtn.addActionListener(new ActionListener(){  
				@Override
				public void actionPerformed(ActionEvent e){  
					System.out.println("in register button");
					String str = e.getActionCommand();
					
					if(str.equals("REGISTER"))
						cl.last(basePanel);
				}			  
				});
			
					
			loginPanel.add(new Label("User Name"));
			loginPanel.add(userName);
			loginPanel.add(new Label("Password"));
			loginPanel.add(password);
			loginPanel.add(submitBtn);
			loginPanel.add(registerBtn);
			
			rf.createForm();
			
			dashBoard.setLoginRef(this);
			
			basePanel.setLayout(cl);
			basePanel.add(loginPanel);
			basePanel.add(dashBoard.getBasePanel());
			basePanel.add(rf.getBasePanel());
			
			
			                  // add panels to frame
		    add(basePanel, "Center");
		    //add(basePanel, "Center");  
		    rf.setLoginRef(this);
		    
		    setSize(600, 600);  
		    setVisible(true) ;
		}catch(Exception e)
		{
			System.out.println(e);
			System.out.println(e.getMessage());
		}
	}
	public void showAlert(String message)
	{
		try
		{			
			Frame f= new Frame();  
			Dialog d = new Dialog(f , "Dialog", true);  
	        d.setLayout( new GridLayout(2,1));//new FlowLayout() );  
	        Button b = new Button ("OK");  
	        b.addActionListener ( new ActionListener()  
	        {  
	            public void actionPerformed( ActionEvent e )  
	            {  
	                d.setVisible(false);  
	            }  
	        });  
	        d.add( new Label (message));  
	        d.add(b);   
	        d.setSize(300,200);    
	        d.setVisible(true);  
			
//			JOptionPane.showMessageDialog(null,message, "INFO",
//                    JOptionPane.INFORMATION_MESSAGE);
		}catch(Exception e)
		{
			System.out.println(e);
		}
	}
	public boolean validateData(String userName,String password)
	{
		login  log=new login();
		String ret=log.loginUser(new UserBean(userName,password));
		if(ret.equalsIgnoreCase("Invalid Input Exeception"))
			return false;
		else
			return true;
		
	}
	/*public static void main(String[] args) {
		LoginPanel obj=new LoginPanel();
		//obj.rf.setLoginRef(obj);
		
	}*/

}
