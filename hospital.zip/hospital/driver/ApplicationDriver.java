package com.hospital.driver;

import com.hospital.layout.LoginPanel;

//import com.hospital.layout.loginPage;

public class ApplicationDriver {
	public static void main(String[] args) {
//		loginPage loginpage = new loginPage();
		LoginPanel obj=new LoginPanel();
	}
}
