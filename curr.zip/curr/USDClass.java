

public class USDClass {

	float usdQty;
	
	USDClass(float usdQty){

		this.usdQty=usdQty;
	}
	
}
